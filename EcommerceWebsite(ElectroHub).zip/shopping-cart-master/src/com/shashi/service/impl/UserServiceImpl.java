package com.shashi.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.shashi.beans.UserBean;
import com.shashi.constants.IUserConstants;
import com.shashi.service.UserService;
import com.shashi.utility.DBUtil;
import com.shashi.utility.MailMessage;

public class UserServiceImpl implements UserService {

    @Override
    public String registerUser(String userName, Long mobileNo, String emailId, String address, int pinCode, String password) {
        UserBean user = new UserBean(userName, mobileNo, emailId, address, pinCode, password);
        return registerUser(user);
    }

    @Override
    public String registerUser(UserBean user) {
        String status = "User Registration Failed!";

        if (isRegistered(user.getEmail())) {
            return "Email Id Already Registered!";
        }

        String query = "INSERT INTO " + IUserConstants.TABLE_USER + " (email, name, mobile, address, pincode, password) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.provideConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, user.getEmail());
            ps.setString(2, user.getName());
            ps.setLong(3, user.getMobile());
            ps.setString(4, user.getAddress());
            ps.setInt(5, user.getPinCode());
            ps.setString(6, user.getPassword());

            int result = ps.executeUpdate();

            if (result > 0) {
                status = "User Registered Successfully!";
                MailMessage.registrationSuccess(user.getEmail(), user.getName().split(" ")[0]);
            }
        } catch (SQLException e) {
            status = "Error: " + e.getMessage();
            e.printStackTrace();
        }

        return status;
    }

    @Override
    public boolean isRegistered(String emailId) {
        String query = "SELECT 1 FROM user WHERE email=?";
        try (Connection con = DBUtil.provideConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, emailId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public String isValidCredential(String emailId, String password) {
        String status = "Login Denied! Incorrect Username or Password";
        String query = "SELECT 1 FROM user WHERE email=? AND password=?";

        try (Connection con = DBUtil.provideConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, emailId);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return "valid";
                }
            }
        } catch (SQLException e) {
            status = "Error: " + e.getMessage();
            e.printStackTrace();
        }

        return status;
    }

    @Override
    public UserBean getUserDetails(String emailId, String password) {
        UserBean user = null;
        String query = "SELECT * FROM user WHERE email=? AND password=?";

        try (Connection con = DBUtil.provideConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, emailId);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    user = new UserBean();
                    user.setName(rs.getString("name"));
                    user.setMobile(rs.getLong("mobile"));
                    user.setEmail(rs.getString("email"));
                    user.setAddress(rs.getString("address"));
                    user.setPinCode(rs.getInt("pincode"));
                    user.setPassword(rs.getString("password"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    @Override
    public String getFName(String emailId) {
        String fname = "";
        String query = "SELECT name FROM user WHERE email=?";

        try (Connection con = DBUtil.provideConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, emailId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    fname = rs.getString(1).split(" ")[0];
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return fname;
    }

    @Override
    public String getUserAddr(String userId) {
        String userAddr = "";
        String query = "SELECT address FROM user WHERE email=?";

        try (Connection con = DBUtil.provideConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    userAddr = rs.getString(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return userAddr;
    }
}
